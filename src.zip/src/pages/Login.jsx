import React, { Component } from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../firebase'

class Login extends Component {
  constructor(props){
    super(props)
    this.state = { email: '', senha: '', mensagem: '' }
    this.handleChange = this.handleChange.bind(this)
    this.acessar = this.acessar.bind(this)
  }

  handleChange(e){
    this.setState({ [e.target.name]: e.target.value })
  }

  async acessar(){
    try{
      await signInWithEmailAndPassword(auth, this.state.email, this.state.senha)
      window.location.hash = '#/home'
    } catch(error){
      this.setState({ mensagem: 'Usuário não cadastrado ou senha inválida' })
    }
  }

  render(){
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="bg-gray-900 border border-gray-800 p-8 rounded-lg shadow-2xl w-96">
          <h1 className="text-2xl font-bold text-center text-gray-100 mb-6">Login</h1>

          <div className="mb-4">
            <label className="block text-gray-300 text-sm font-bold mb-2">E-mail</label>
            <input name="email" type="email" value={this.state.email} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <div className="mb-6">
            <label className="block text-gray-300 text-sm font-bold mb-2">Senha</label>
            <input name="senha" type="password" value={this.state.senha} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <button onClick={this.acessar} className="w-full bg-blue-500 text-white py-2 rounded-md">Acessar</button>

          {this.state.mensagem && (
            <div className="mt-4 p-3 rounded-md text-center bg-red-900/40 text-red-300">{this.state.mensagem}</div>
          )}
        </div>
      </div>
    )
  }
}

export default Login
