import React, { Component } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { doc, getDoc } from 'firebase/firestore'
import { auth, db } from '../firebase'
import UserProfile from '../components/UserProfile'

class Home extends Component {
  constructor(props){
    super(props)
    this.state = { nome: '', sobrenome: '', dataNascimento: '', carregando: true }
  }

  componentDidMount(){
    this.unsubscribe = onAuthStateChanged(auth, async (user) => {
      if(user){
        const uid = user.uid
        const snap = await getDoc(doc(db, 'users', uid))
        if(snap.exists()){
          const data = snap.data()
          this.setState({ nome: data.nome || '', sobrenome: data.sobrenome || '', dataNascimento: data.dataNascimento || '', carregando: false })
        } else {
          this.setState({ carregando: false })
        }
      } else {
        window.location.hash = '#/login'
      }
    })
  }

  componentWillUnmount(){
    if(this.unsubscribe) this.unsubscribe()
  }

  render(){
    if(this.state.carregando){
      return <div className="p-8 text-center text-gray-200">Carregando...</div>
    }
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <UserProfile nome={this.state.nome} sobrenome={this.state.sobrenome} dataNascimento={this.state.dataNascimento} />
      </div>
    )
  }
}

export default Home