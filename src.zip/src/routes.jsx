import React from 'react'
import { HashRouter as Router, Routes, Route } from 'react-router-dom'
import Login from './pages/Login'
import Cadastro from './pages/Cadastro'
import Home from './pages/Home'
import Navbar from './components/Navbar'

export default function AppRoutes(){
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Cadastro />} />
        <Route path="/register" element={<Cadastro />} />
        <Route path="/login" element={<Login />} />
        <Route path="/home" element={<Home />} />
      </Routes>
    </Router>
  )
}
