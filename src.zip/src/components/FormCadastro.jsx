import React, { Component } from 'react'
import { createUserWithEmailAndPassword } from 'firebase/auth'
import { doc, setDoc } from 'firebase/firestore'
import { auth, db } from '../firebase'

class FormCadastro extends Component {
  constructor(props){
    super(props)
    this.state = {
      email: '',
      senha: '',
      nome: '',
      sobrenome: '',
      dataNascimento: '',
      mensagem: ''
    }

    this.handleChange = this.handleChange.bind(this)
    this.cadastrar = this.cadastrar.bind(this)
  }

  handleChange(e){
    this.setState({ [e.target.name]: e.target.value })
  }

  async cadastrar(){
    const { email, senha, nome, sobrenome, dataNascimento } = this.state
    try{
      const userCred = await createUserWithEmailAndPassword(auth, email, senha)
      const uid = userCred.user.uid
      await setDoc(doc(db, 'users', uid), {
        uid,
        email,
        nome,
        sobrenome,
        dataNascimento
      })
      this.setState({ mensagem: 'Usuário cadastrado com sucesso!' })
      window.location.hash = '#/login'
    } catch(error){
      this.setState({ mensagem: 'Erro no cadastro: ' + error.message })
    }
  }

  render(){
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="bg-gray-900 border border-gray-800 p-8 rounded-lg shadow-2xl w-96">
          <h1 className="text-2xl font-bold text-center text-gray-100 mb-6">Cadastro</h1>

          <div className="mb-3">
            <label className="block text-gray-300 text-sm font-bold mb-2">E-mail</label>
            <input name="email" type="email" value={this.state.email} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <div className="mb-3">
            <label className="block text-gray-300 text-sm font-bold mb-2">Senha</label>
            <input name="senha" type="password" value={this.state.senha} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <div className="mb-3">
            <label className="block text-gray-300 text-sm font-bold mb-2">Nome</label>
            <input name="nome" type="text" value={this.state.nome} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <div className="mb-3">
            <label className="block text-gray-300 text-sm font-bold mb-2">Sobrenome</label>
            <input name="sobrenome" type="text" value={this.state.sobrenome} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <div className="mb-6">
            <label className="block text-gray-300 text-sm font-bold mb-2">Data de Nascimento</label>
            <input name="dataNascimento" type="date" value={this.state.dataNascimento} onChange={this.handleChange}
              className="w-full px-3 py-2 border border-gray-700 bg-gray-800 text-gray-100 rounded-md" />
          </div>

          <button onClick={this.cadastrar} className="w-full bg-green-600 text-white py-2 rounded-md">Cadastrar</button>

          {this.state.mensagem && (
            <div className="mt-4 p-3 rounded-md text-center bg-blue-900/40 text-blue-200">{this.state.mensagem}</div>
          )}
        </div>
      </div>
    )
  }
}

export default FormCadastro
