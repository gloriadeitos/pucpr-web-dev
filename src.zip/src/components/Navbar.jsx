import React from 'react'
import { Link } from 'react-router-dom'

export default function Navbar(){
  return (
    <div className="p-4 bg-gray-900 text-gray-100">
      <nav className="flex gap-4 mb-4">
        <Link to="/" className="text-blue-400">Home</Link>
        <Link to="/login" className="text-blue-400">Entrar</Link>
        <Link to="/register" className="text-blue-400">Cadastro</Link>
      </nav>
    </div>
  )
}
