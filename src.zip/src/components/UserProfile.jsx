import React from 'react'

export default function UserProfile({ nome, sobrenome, dataNascimento }){
  return (
    <div className="bg-gray-900 border border-gray-800 p-8 rounded-lg shadow-2xl w-96 text-gray-100">
      <p><strong>Nome:</strong> {nome}</p>
      <p><strong>Sobrenome:</strong> {sobrenome}</p>
      <p><strong>Data de Nascimento:</strong> {dataNascimento}</p>
    </div>
  )
}
